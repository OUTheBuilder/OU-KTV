# O|U KTV — Fresh Android Project

This is a new Android Studio project built from the user-provided `base.apk` reference. It does not use Floot. The original embedded karaoke UI/client code and its player assets are packaged in `app/src/main/assets/www/` and wrapped in a new Android WebView application.

## Current build status (2026-10-31)

- The Android wrapper and original embedded O|U KTV web client are included.
- The GitHub Actions workflow now explicitly installs Gradle 8.11.1, which matches the Android Gradle Plugin 8.9.2 requirement, and uses current checkout/setup-java actions.
- A backend is **not** included or deployed yet. The supplied client is a self-hosted REST + WebSocket client; it is not a native Appwrite client. Its meta tags currently contain `__PUBLIC_URL__` and `__ANONKEY__` placeholders. The provided ID `6ae344d2001bae2330e2` alone is not enough to configure or deploy an Appwrite/Supabase backend.
- Do not put a database/service-role secret in the Android app. A public client key is not a substitute for server-side authorization.

## Important status

- Android project/source: created.
- Reference UI and client-side controls: included from the supplied APK's embedded web application.
- Android APK: **not compiled in this environment** because Android SDK/Gradle build tooling is not installed here.
- Backend: the original client expects an HTTPS API and WebSocket server. The project is not a fully working standalone offline app until that server is deployed and its URL is configured.
- YouTube playback/search availability depends on YouTube's current embed/API restrictions and the user's network.

## Backend contract

The embedded client calls a server at the configured HTTPS base URL. It expects JSON REST endpoints under `/api` and a WebSocket endpoint at `/ws?room=<CODE>`. The visible client calls include `/config`, `/login`, `/search`, `/popular`, `/ktvs`, `/ktv/check/:code`, `/qr/:code`, `/room/:code/action`, `/admin/login`, `/admin/config`, `/admin/logins`, `/admin/users`, and `/admin/rooms`. Admin routes must enforce authorization on the server. Room state must be authoritative on the server and broadcast to connected room clients.

## Configure backend URL

Open `app/src/main/assets/www/index.html` and find:

```html
<meta name="public-url" content="https://YOUR-KTV-SERVER.example">
```

Replace the example host with the HTTPS address of your compatible KTV backend. The frontend uses `/api/*` endpoints and a `/ws?room=...` WebSocket endpoint. The current source expects endpoints including `/config`, `/login`, `/search`, `/popular`, `/ktvs`, `/ktv/check/:code`, `/room/:code/action`, and `/admin/*`.

Do not ship an app that points at the placeholder URL. A real server and secure admin authentication are required for multi-phone rooms and admin tools.

## Build in Android Studio

1. Install Android Studio and its Android SDK (API 35).
2. Open this folder (`OU-KTV-Fresh`) as a project.
3. Let Gradle sync and download the Android Gradle Plugin and AndroidX WebKit dependency.
4. Build > Build APK(s).
5. Debug APK output should be `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK using GitHub Actions

Push this project to a GitHub repository. The workflow at `.github/workflows/android.yml` builds a debug APK and uploads it as an artifact. It does not deploy a backend. The repository must contain the project at its root (the `app/` folder and `settings.gradle`).

## Original reference features visible in the packaged client

Landing/login and registration, create/join KTV rooms, QR join flow, search and popular songs, genre filtering, queue rendering, host and remote playback controls, cheers, settings, theme and skin selection, branding, footer/custom buttons, admin login, admin configuration, login records, user list, and room administration.

Some controls depend on server responses, permissions, credentials, and remote APIs. Packaging the UI alone does not guarantee every remote function is operational; test against the deployed backend before distributing.
