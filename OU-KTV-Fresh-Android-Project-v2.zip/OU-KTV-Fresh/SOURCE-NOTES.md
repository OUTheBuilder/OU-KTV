# Source notes

The reference APK's archive contains `assets/www/ktv-app.html`, `assets/www/ext/video.min.js`, `assets/www/ext/Youtube.min.js`, `assets/www/ext/video-js.css`, and Poppins font files. The new project packages the HTML as `app/src/main/assets/www/index.html`, adjusts the local player asset paths to be relative, and adds a new Android WebView wrapper under package `com.ouktv.app`.

This is a fresh Android project wrapper around the reference app's embedded client. It is not a decompilation/rebuild of the original compiled Kotlin/Java app, and it does not contain the original server/database because those were not present in the uploaded APK archive.
