# O|U KTV repaired source bundle

- `ktv-server/` contains the repaired runnable project.
- `ORIGINAL_SOURCE_CODE.txt` is the original uploaded source bundle, preserved unchanged for reference.

Start with `ktv-server/README.md` for installation, environment variables, migration notes, and tests.

This is a source-code repair package. It has not been deployed to your hosting provider or pushed to GitHub.
